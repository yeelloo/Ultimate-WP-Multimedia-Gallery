<?php
if (!defined('ABSPATH')) exit;
?>
	<section id="wpmg_heaher">
		<div class="wpmg_logo">
	    	<img src="<?php echo WPMG__URL ?>/admin/images/uwmg-logo484x110.png">
	    </div>
	    <div class="wpmg_version">
	    	<code><?php echo 'v'.WPMG_VERSION ?></code>
	    </div>
	</section>