
<?php
if (!defined('ABSPATH')) exit;
add_thickbox(); 
?>

<div id="addNewGalleryThickbox" style="display:none;">
     <p style="margin-bottom: 0">
        <input type="text" name="galleryTitle" id="addNewGalleryTitle" placeholder="Gallery Name">
     	<input type="button" class="button" value="Create Gallery" id="addNewGalleryBtn">
     </p>
</div>	